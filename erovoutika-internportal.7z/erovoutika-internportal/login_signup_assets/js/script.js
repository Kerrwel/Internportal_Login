function popup_error()
{
    Swal.fire(
        'Wrong Username or Password!',
        '',
        'error'
    )
}
function unmatched_password_popup()
{
    Swal.fire(
        'Passwords do not matched!',
        '',
        'error'
    ),$('#id01').modal('show');
}

function existing_email_popup()
{
    Swal.fire(
        'Email already exists!',
        '',
        'error'
    ),$('#id01').modal('show');
}

function signup_popup_success()
{
    Swal.fire(
        'Data has been saved successfully!',
        '',
        'success'
    ).then(function(){window.location.href = "";});
}

function submit_success_popup()
{
    Swal.fire(
        'Data has been saved successfully!',
        '',
        'success'
    ).then(function(){window.location.href = "";});
}
function register_date_failed_popup()
{
    Swal.fire(
        'Age is below 18!',
        '',
        'error'
    ),$('#id01').modal('show');
}
