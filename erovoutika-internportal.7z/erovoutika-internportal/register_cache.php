<?php

if (isset($_SESSION['inputted_first_name']))
{
    $INPUTTED_FIRST_NAME = $_SESSION['inputted_first_name'];
}

else
{
    $INPUTTED_FIRST_NAME = "";
}

if (isset($_SESSION['inputted_last_name']))
{
    $INPUTTED_LAST_NAME = $_SESSION['inputted_last_name'];
}

else
{
    $INPUTTED_LAST_NAME = "";
}

if (isset($_SESSION['inputted_middle_name']))
{
    $INPUTTED_MIDDLE_NAME = $_SESSION['inputted_middle_name'];
}

else
{
    $INPUTTED_MIDDLE_NAME = "";
}

if (isset($_SESSION['inputted_suffix_name']))
{
    $INPUTTED_SUFFIX_NAME = $_SESSION['inputted_suffix_name'];
}

else
{
    $INPUTTED_SUFFIX_NAME = "";
}


if (isset($_SESSION['inputted_birthday']))
{
    $INPUTTED_BIRTHDAY = $_SESSION['inputted_birthday'];
}

else
{
    $INPUTTED_BIRTHDAY = "";
}

if (isset($_SESSION['inputted_number']))
{
    $INPUTTED_NUMBER = $_SESSION['inputted_number'];
}

else
{
    $INPUTTED_NUMBER = "";
}

if (isset($_SESSION['inputted_email']))
{
    $INPUTTED_EMAIL = $_SESSION['inputted_email'];
}

else
{
    $INPUTTED_EMAIL = "";
}

if (isset($_SESSION['inputted_pass1']))
{
    $INPUTTED_PASS1 = $_SESSION['inputted_pass1'];
}

else
{
    $INPUTTED_PASS1 = "";
}

if (isset($_SESSION['inputted_pass2']))
{
    $INPUTTED_PASS2 = $_SESSION['inputted_pass2'];
}

else
{
    $INPUTTED_PASS2 = "";
}

?>