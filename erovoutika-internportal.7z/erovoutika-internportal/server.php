<?php
    session_start(); // cache

    /* Set database connection */

    /* get all DB parameters */
    $SERVER = "localhost";
    $USER = "root";
    $PASS = "";
    $DATABASE = "DB_INTP_PUBL";

    /* setup DB connection string */

    $CONN = mysqli_connect($SERVER, $USER, $PASS, $DATABASE);

    if (!$CONN)
    {
        die("Error in Database Connection!");
    }

    /* LOGIN */

    if (isset($_POST['login']))
    {
        /* get all POST data from the login form */
        $LOGIN_EMAIL = mysqli_real_escape_string($CONN, $_POST['login_email']);
        $LOGIN_PASSWORD = mysqli_real_escape_string($CONN, $_POST['login_password']);

        $_SESSION['login_email'] = $LOGIN_EMAIL;

        $QUERY = "SELECT * FROM `tbl_user_acct_list` WHERE `col_emai_addr` = '". $LOGIN_EMAIL ."' AND `col_user_pass` = '". $LOGIN_PASSWORD ."' LIMIT 1";
        $RESULT = mysqli_query($CONN, $QUERY);

        if (mysqli_num_rows($RESULT) > 0)
        {
            while ($USER_DETAILS = mysqli_fetch_array($RESULT))
            {
                $_SESSION['current_first'] = $USER_DETAILS['col_frst_name'];
                $_SESSION['current_middle'] = $USER_DETAILS['col_midl_name'];
                $_SESSION['current_last'] = $USER_DETAILS['col_last_name'];
                $_SESSION['current_suffix'] = $USER_DETAILS['col_sufx_name'];
                $_SESSION['current_email'] = $USER_DETAILS['col_emai_addr'];
                $_SESSION['current_birthday'] = $USER_DETAILS['col_birt_date'];
                $_SESSION['current_number'] = $USER_DETAILS['col_cell_numb'];
                $_SESSION['current_user_id'] = $USER_DETAILS['id'];
            }

            $_SESSION['login_status'] = "success";
            $_SESSION['is_login'] = "true";

            unset($_SESSION['login_email']);
            unset($LOGIN_EMAIL);
        }

        else
        {
            $_SESSION['login_status'] = "failed";
        }
    }

    /* Check login status */
    if (isset($_SESSION['login_status']))
    {
        if ($_SESSION['login_status'] == "success")
        {
            header("location: step1.php");
        }

        else
        {
            $LOGIN_LOADER = "popup_error()";
            
        }
    }

    else
    {
        $LOGIN_LOADER = "";
    }
    /* REGISTER */
    if (isset($_POST['register']))
    {
        /*get all data from the Sign Up form */

        $REG_FIRST_NAME = $_POST['signup_first_name'];
        $REG_MIDDLE_NAME = $_POST['signup_middle_name'];
        $REG_LAST_NAME = $_POST['signup_last_name'];
        $REG_SUFFIX = $_POST['signup_suffix_name'];
        $REG_BIRTHDAY = $_POST['signup_birthday'];
        $REG_EMAIL = $_POST['signup_email'];
        $REG_NUMBER = $_POST['signup_number'];
        $REG_PASSWORD = $_POST['signup_password'];
        $REG_CONFIRM_PASSWORD = $_POST['signup_confirm_password'];

        $_SESSION['inputted_first_name'] = $REG_FIRST_NAME;
        $_SESSION['inputted_middle_name'] = $REG_MIDDLE_NAME;
        $_SESSION['inputted_last_name'] = $REG_LAST_NAME;
        $_SESSION['inputted_suffix_name'] = $REG_SUFFIX;
        $_SESSION['inputted_birthday'] = $REG_BIRTHDAY;
        $_SESSION['inputted_email'] = $REG_EMAIL;
        $_SESSION['inputted_number'] = $REG_NUMBER;
        $_SESSION['inputted_pass1'] = $REG_PASSWORD;
        $_SESSION['inputted_pass2'] = $REG_CONFIRM_PASSWORD;
        


        /* Check if passswords are matched */

        if ($REG_PASSWORD != $REG_CONFIRM_PASSWORD)
        {
            $_SESSION['signup_status'] = "unmatched_password";
        }

        /* Check if email already exists */
        
        $QUERY = "SELECT * FROM `tbl_user_acct_list`";
        $RESULT = mysqli_query($CONN, $QUERY);

        if (mysqli_num_rows($RESULT) > 0)
        {
            while ($USER_DETAILS = mysqli_fetch_array($RESULT))
            {
                $USER_INPUTTED_EMAIL = $USER_DETAILS['col_emai_addr'];
            }

            if ($REG_EMAIL == $USER_INPUTTED_EMAIL)
            {
                $_SESSION['signup_status'] = "existing_email";
            }
        }
        // $bday = new DateTime($REG_BIRTHDAY); // Your date of birth
        // $today = new Datetime(date('m.d.y'));
        // $diff = $today->diff($bday);
        // ($diff->y);
        
        // if ($diff > 18)
        // {
        //     $_SESSION['signup_status'] = "register_date_failed";         
           
        // }

        /* Register User */
        if (($REG_PASSWORD == $REG_CONFIRM_PASSWORD) && ($REG_EMAIL != $USER_INPUTTED_EMAIL))
        {
            $QUERY = "INSERT INTO `tbl_user_acct_list` (`col_frst_name`, `col_midl_name`, `col_last_name`, `col_sufx_name`,`col_birt_date`, `col_emai_addr`, `col_cell_numb`, `col_user_pass`) VALUES ('". $REG_FIRST_NAME ."', '". $REG_MIDDLE_NAME ."', '". $REG_LAST_NAME ."', '". $REG_SUFFIX ."', '". $REG_BIRTHDAY ."', '". $REG_EMAIL ."', '". $REG_NUMBER ."', '". $REG_PASSWORD ."')";
            $RESULT = mysqli_query($CONN, $QUERY);

            $_SESSION['signup_status'] = "register_success";

            unset($REG_FIRST_NAME);
            unset($REG_MIDDLE_NAME);
            unset($REG_LAST_NAME);
            unset($REG_SUFFIX);
            unset($REG_AGE);
            unset($REG_BIRTHDAY);
            unset($REG_EMAIL); 
            unset($REG_NUMBER); 
            unset($REG_PASSWORD); 
            unset($REG_CONFIRM_PASSWORD);
            unset($_SESSION['inputted_first_name']);
            unset($_SESSION['inputted_middle_name']); 
            unset($_SESSION['inputted_last_name']);
            unset($_SESSION['inputted_suffix_name']);
            unset($_SESSION['inputted_birthday']); 
            unset($_SESSION['inputted_email']);
            unset($_SESSION['inputted_number']);
            unset($_SESSION['inputted_pass1']);
            unset($_SESSION['inputted_pass2']);
        }
    }
        

    /* Check Sign In status */

    if (isset($_SESSION['signup_status']))
    {
        if ($_SESSION['signup_status'] == "register_success")
        {
            $SIGNUP_LOADER = "signup_popup_success()";
        }

        if ($_SESSION['signup_status'] == "unmatched_password")
        {
            $SIGNUP_LOADER = "unmatched_password_popup()";
            
        }

        if ($_SESSION['signup_status'] == "existing_email")
        {
            $SIGNUP_LOADER = "existing_email_popup()";
        }

        // if ($_SESSION['signup_status'] == "register_date_failed")
        // {
        //     $SIGNUP_LOADER = "register_date_failed_popup()";
        // }
    }

    else
    {
        $SIGNUP_LOADER = "";
    }

       

?>
