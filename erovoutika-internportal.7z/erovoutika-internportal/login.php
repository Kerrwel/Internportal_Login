<?php include("server.php"); ?>
<!DOCTYPE html>

<html>
  
  <head>

    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <meta name="google-signin-client_id" class = 'google_sign' content="614906115268-vtvfs1ihge1ufbhu73ct32s0skav8ffc.apps.googleusercontent.com">
    
    <title>Erovoutika -  Intern Portal</title>

    <meta property="og:url" content="https://intern.erovoutika.ph"/>
    <meta property="og:image" content="https://intern.erovoutika.ph/images/internportal_bg_img.jpg"/>
    <meta property="og:title" content="Erovoutika - Virtual Internship Portal"/>
    <meta property="og:type" content="website"/>
    <link rel="icon" href="login_signup_assets/images/beta-logo.png" type="image/gif" sizes="32x32">
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="login_signup_assets/css/Login_page.css" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  </head>

  <body onload="<?php echo $LOGIN_LOADER; ?><?php echo $SIGNUP_LOADER; ?>"
    
    <?php

        unset($LOGIN_LOADER);
        unset($_SESSION['login_status']);

    ?>
    <?php

        unset($SIGNUP_LOADER);
        unset($_SESSION['signup_status']);

    ?>
    
    <div class="all_background">
      
      <div class="container-fluid">
        
        <div class="row">

          <div class="col-md-6">
          
            <div class="head_img a1">
            
              <img src="login_signup_assets/images/internportal_bg_img.jpg" class="img-fluid">
          
            </div>
        
          </div>


        <div class="col-md-6">
          
          <div class="center">
            
            <div class="form_box pt-3 pb-3">
              
              <form action="" method="POST" id="frmLogin"> 
                
              <?php

                if (isset($_SESSION['login_email']))
                {
                    $USER_EMAIL = $_SESSION['login_email'];
                }

                else
                {
                    $USER_EMAIL = "";
                }

              ?>
            
                <div class="form-group">
                  
                  <input type="email" class="form-control input_email"  id="email" name='login_email' aria-describedby="emailHelp" placeholder="Enter email" value="<?php echo $USER_EMAIL; ?>" required>
        
                  
                  <div id='emailreq'></div>
                
                </div>

                <div class="form-group">
                  
                  <input type="password" class='form-control password input_password' name="login_password" id="password" placeholder="Password" value="">
                
                </div>

                <div class="form-group">
                  
                  <input type="submit" name="login" value="Login" class="btn btn-primary Log-btn">
                
                </div>

                <div class="col-8 form-inline ml-1">
                  
                  <input type="checkbox" name="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?> class=" "> 
                  <label>Remember me</label>
                
                </div>

                <hr>

              </form>

              <div class="card p-3" id='show_mobile_caution' style="display:none;">
                
                <h5>Erovoutika Intern Portal can be accessed only on computer.</h5>
              
              </div>

              <div class="signup_btn">
                
                <a class="btn btn-success text-white" data-toggle="modal" data-target="#id01"><h5 class="mb-0 p-1">Create New Account</h5></a>
              
              </div>
            
            </div>
          
          </div>
        
        </div>
      
      </div>
    
    </div>
    

    <div class="background_Body">
      
      <!-- MODAL HERE -->
      
      <div id="id01" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        
        <div class="modal-dialog" role="document">
          
          <div class="modal-content">

            <div class="modal-header pb-0 flex-column position-relative" style="max-height: 100px !important;">
              
              <h2 class="modal-title" id="exampleModalLabel">Sign up</h2>
              
              <p class="text-muted Sign_mute pb-0">Intern Registration</p>
              
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                
                <span aria-hidden="true">&times;</span>
              
              </button>
              
              <br>
            
            </div>
            
            <div class="modal-body">
              
              <form method="POST" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
              
               
                <?php include("register_cache.php"); ?>
                
                
                <div class="form-row text-center ">                      
                  <input type="text" class="form-control" name='signup_first_name' id="Fname" placeholder="First Name" value="<?php echo $INPUTTED_FIRST_NAME; ?>" required>
                  <input type="text" class="form-control" name='signup_last_name' id="Lname" placeholder="Last Name" value="<?php echo $INPUTTED_LAST_NAME; ?>" required>
                  <input type="text" class="form-control" name='signup_middle_name' id="Mname" placeholder="Middle Name" value="<?php echo $INPUTTED_MIDDLE_NAME; ?>" required>
                  <input type="text" class="form-control" name='signup_suffix_name' id="Sname" placeholder="Suffix Name" value="<?php echo $INPUTTED_SUFFIX_NAME; ?>">
                  <input type="date" class="form-control" name='signup_birthday' id="birthday" value="<?php echo $INPUTTED_BIRTHDAY; ?>" required>
                  <input type="email" class="form-control" name='signup_email' id="Email1" placeholder="Email" value="<?php echo $INPUTTED_EMAIL; ?>" required>
                  <input type="text" class="form-control" name='signup_number' id="mNumber" placeholder="Mobile Number" value="<?php echo $INPUTTED_NUMBER; ?>" required >

                  <input type="password" class="form-control" name='signup_password' id="password" placeholder="Password" value="<?php echo $INPUTTED_PASS1; ?>" required>          
                  <input type="password" class="form-control" name='signup_confirm_password' id="confirm_password" placeholder="Confirm Password" onchange="check_passwords()" value="<?php echo $INPUTTED_PASS2; ?>"  required>
                  
                  <div class="w-100 text-left pt-2" style="text-align: justify !important; width: 338.9px !important; margin-left: 16px;">
                    
                    <div class="show-second icheck-primary pb-3" style="font-size: 16px; display: block;">
                              
                      <input type="checkbox" id="agreeTerms" isagree="false" name="terms" value="agree" required>
                              
                      <label for="agreeTerms" style="font-size: 10px;">
                                
                        We're committed to your privacy, Erovoutika Intern Portal uses the information you provide to us to contact you about our relevant
                        content, concerns, and service. You may unsubscribe from these sommunications at any time. For more information, check out our <a href="#">Privacy Policy</a>.
                              
                      </label>
                          
                    </div>
                      
                  </div>
                  
                </div>

                <div class="modal-footer justify-content-center" style="width: 100%;">
                
                  <button type="submit" name="register" class='reg-btn btn-signUp btn btn-success' id="reg-btn" >
                  
                    <h5 class="p-1 mb-0">Sign Up</h5>
                    
                  </button>
                  
                </div>
                
              </form>  
              
            </div>
              
          </div>
          
        </div>
        
      </div>

    </div> 
    <!-- MODAL END -->
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <script>

      // Get the modal
      var modal = document.getElementById('id01');

      // screen adjustment
      // ============================================== script for screen size adjustment ==============================

      function myFunction(x) 
      {    
        if (x.matches) 
        {
          $('#frmLogin').hide();
          $('.signup_btn').hide();
          $('#show_mobile_caution').show();
        } 
        
        else 
        {
          //selector.style
          $('#frmLogin').show();
          $('.signup_btn').show();
          $('#show_mobile_caution').hide();
        }
      }

      var x = window.matchMedia("(max-width: 767px)");
      myFunction(x); // Call listener function at run time
      x.addListener(myFunction); // Attach listener function on state changes

    </script>
    <script src="login_signup_assets/js/script.js"></script>
  </body>
    
</html>